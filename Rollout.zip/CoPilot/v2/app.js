let data = null;

const nav = document.getElementById("sheet-nav");
const title = document.getElementById("sheet-title");
const tbody = document.querySelector("#sheet-table tbody");

async function loadData() {
  const response = await fetch("data.json");
  data = await response.json();
  renderNav();
  renderSheet(0);
}

function renderNav() {
  nav.innerHTML = "";
  data.sheets.forEach((sheet, index) => {
    const btn = document.createElement("button");
    btn.textContent = sheet.name;
    btn.onclick = () => renderSheet(index);
    nav.appendChild(btn);
  });
}

function renderSheet(index) {
  const sheet = data.sheets[index];
  title.textContent = sheet.name;

  [...nav.children].forEach((btn, i) => {
    btn.classList.toggle("active", i === index);
  });

  tbody.innerHTML = "";
  sheet.items.forEach(item => {
    const tr = document.createElement("tr");

    if (item.status === "Green") tr.classList.add("status-Green");
    if (item.status === "Red") tr.classList.add("status-Red");
    if (item.status === "Amber") tr.classList.add("status-Amber");

    tr.innerHTML = `
      <td>${item.title}</td>
      <td>${item.owner}</td>
      <td>${item.contributors.join(", ")}</td>
      <td>${item.lifecycleStage}</td>
      <td>${item.reviewCadence}</td>
      <td>${item.status}</td>
      <td>${item.notes}</td>
    `;
    tbody.appendChild(tr);
  });
}

loadData();
