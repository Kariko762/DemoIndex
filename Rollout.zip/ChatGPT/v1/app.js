
const DATA = {
  mandate: {
    label:"THE EXECUTIVE TEST", title:"What does success actually mean?",
    sub:"The platform is the enabler. The operating model is the differentiator.",
    html:`<div class="grid">
      <div class="card wide"><span class="view-label">NORTH STAR</span><h3>A governed digital experience capability</h3><p>Coast should let the organization create, deliver, share and learn from customer-facing experiences — without turning the central team into a production bottleneck.</p><div class="metric">70,000</div><div class="metric-label">employee enterprise context</div></div>
      <div class="card"><span class="view-label">THE SHIFT</span><h3>From → To</h3><div class="list">
        <div class="list-item"><span>Static collateral</span><span>Interactive journeys</span></div>
        <div class="list-item"><span>Bespoke demos</span><span>Reusable experiences</span></div>
        <div class="list-item"><span>Logins & licenses</span><span>Behavior & value</span></div>
        <div class="list-item"><span>Central production</span><span>Federated creation</span></div>
      </div></div>
      <div class="card full"><span class="view-label">FIVE EXECUTIVE OUTCOMES</span><div class="tile-row">
        ${["Desired behavior","Independent capability","Less specialist friction","Buyer engagement","Commercial impact"].map((x,i)=>`<div class="mini-tile" data-modal="${i}"><strong>0${i+1}</strong><span>${x}</span></div>`).join("")}
      </div></div>
      <div class="card full"><span class="view-label">RECOMMENDED MANDATE</span><p style="font-size:16px;color:#e9eaff;line-height:1.55">“Coast is the governed digital experience platform for priority commercial journeys.”</p><p style="margin-top:10px">Product owns the truth · Marketing owns the market narrative · Enablement owns behavior change · Demo Services owns operational reliability · RevOps owns the enterprise operating model and value realization · Business leaders own adoption and commercial outcomes.</p></div>
    </div>`
  },
  model: {
    label:"CENTRAL PLATFORM · FEDERATED CONTENT", title:"The operating model", sub:"Separate strategic authority from creation capacity.",
    html:`<div class="grid">
      <div class="card wide"><span class="view-label">DESIGN PRINCIPLE</span><h3>Central platform. Federated content. Governed experience.</h3><p>The central team owns the platform and system of work. LoB and product teams retain product truth. Enablement owns the people-side transition. Field teams generate demand and usage. Analytics connects the platform to commercial outcomes.</p></div>
      <div class="card"><span class="view-label">ANTI-BOTTLENECK</span><h3>Do not make “the Coast team” accountable for everything.</h3><p>Centralize standards and controls — not every build. A 70,000-person enterprise requires distributed creation inside guardrails.</p></div>
      <div class="card full"><span class="view-label">ACCOUNTABILITY MAP · CLICK A ROLE</span><div class="tile-row">${[
        ["RevOps","Outcome + operating model"],["Platform Owner","Platform + roadmap"],["Design CoE","UX + templates"],["Product / LoB","Product truth"],["Enablement","Behavior change"],["Demo Services","Readiness + support"],["Marketing","Brand + channels"],["IT / Security","Controls + identity"],["Data","Telemetry + ROI"],["Sales Leaders","Local adoption"]
      ].map((r,i)=>`<div class="mini-tile" data-role="${i}"><strong>${r[0]}</strong><span>${r[1]}</span></div>`).join("")}</div></div>
      <div class="card wide"><span class="view-label">CADENCE</span><div class="list">${[
        ["Executive Sponsor","Quarterly"],["RevOps Program Owner","Weekly / Monthly"],["Platform Owner","Weekly"],["Product / LoB Owners","Biweekly"],["Enablement / Change","Weekly"],["Demo Services / Operations","Daily / Weekly"],["Data & Analytics","Monthly"],["Sales Leadership / Managers","Weekly"]
      ].map(x=>`<div class="list-item"><span>${x[0]}</span><span>${x[1]}</span></div>`).join("")}</div></div>
      <div class="card"><span class="view-label">ACCOUNTABILITY RULE</span><div class="metric">1</div><div class="metric-label">accountable owner per decision</div><p style="margin-top:12px">Avoid multiple A's in the RACI.</p></div>
    </div>`
  },
  lifecycle: {
    label:"EIGHT STAGES · BUSINESS GATES", title:"Deployment is a product launch, not an IT install.", sub:"Each stage has an outcome, questions and an explicit exit gate.",
    html:`<div class="card full" style="margin-bottom:14px"><div class="timeline">${[
      ["0","Mobilize","Mandate, outcomes, scope, sponsor, funding","Charter approved"],
      ["1","Discover","Audiences, journeys, pain points, baseline","2–4 use cases selected"],
      ["2","Design","Governance, taxonomy, templates, controls","Target model approved"],
      ["3","Build","Experience factory, components, analytics","Pilot-ready QA"],
      ["4","Pilot","Controlled cohort + real customer use","Evidence of value"],
      ["5","Scale","Waves, champions, campaigns, support","Targets met"],
      ["6","Embed","Onboarding + process integration","Default in workflows"],
      ["7","Optimize","Analytics, A/B, retirement, ROI","Self-sustaining cycle"]
    ].map(s=>`<div class="stage" data-stage="${s[0]}"><span class="stage-num">STAGE ${s[0]}</span><h4>${s[1]}</h4><p>${s[2]}</p><div class="gate">↳ ${s[3]}</div></div>`).join("")}</div></div>
      <div class="grid">
        <div class="card wide"><span class="view-label">THE GATE LOGIC</span><h3>No scale without evidence.</h3><p>At each gate, ask whether the organization has proven the business outcome, ownership, behavior, quality and operational readiness required for the next level of investment.</p></div>
        <div class="card"><span class="view-label">PILOT RULE</span><h3>2–4 use cases</h3><p>Select based on value, readiness and repeatability — not enthusiasm alone.</p></div>
      </div>`
  },
  adoption: {
    label:"BEHAVIOR OVER LICENSES", title:"Adoption is a progression.", sub:"Measure depth against the eligible cohort — not the 70,000-person enterprise.",
    html:`<div class="grid">
      <div class="card wide"><span class="view-label">ADOPTION LADDER</span><div class="tile-row">${[
        ["Eligible","Defined cohort + valid use case"],["Provisioned","Role-appropriate access"],["Activated","Meaningful first task"],["Capable","Independent core workflow"],["Repeated","Multiple relevant workflows"],["Embedded","Part of standard process"],["Advocating","Teaches + contributes"]
      ].map(x=>`<div class="mini-tile"><strong>${x[0]}</strong><span>${x[1]}</span></div>`).join("")}</div></div>
      <div class="card"><span class="view-label">12-MONTH TARGET</span><div class="metric">60%+</div><div class="metric-label">repeated use in priority cohorts</div><p style="margin-top:12px">85% activated · 50%+ embedded</p></div>
      <div class="card full"><span class="view-label">PLANNING ENVELOPE</span><div class="bars">${[
        ["30d","50%",20],["90d","70%",45],["180d","80%",60],["12m","85%",75]
      ].map(x=>`<div class="bar-wrap"><div class="bar-value">${x[1]}</div><div class="bar" style="height:${x[2]}%"></div><div class="bar-label">${x[0]} activation</div></div>`).join("")}</div><p>Recommended management targets, not external benchmarks. Provisioning targets reach 95% in priority cohorts by 12 months.</p></div>
      <div class="card full"><span class="view-label">ADOPTION INDEX</span><h3>25% Activation + 25% Repeat Usage + 20% Independent Capability + 15% Embedded Workflow Use + 15% Advocacy</h3><p>Track by cohort and wave. Keep business value separate from the adoption index.</p></div>
    </div>`
  },
  governance: {
    label:"DECISION RIGHTS", title:"Governance without bureaucracy.", sub:"Three levels resolve strategy, operating decisions and content truth.",
    html:`<div class="grid">
      ${[
        ["Executive Steering Committee","Sponsor + RevOps + Sales / Marketing / Product leaders","Strategy · funding · outcomes · risk · exceptions","Monthly / quarterly"],
        ["Coast Platform Council","Platform Owner + RevOps + Enablement + Demo Services + IT + Data + Marketing","Standards · backlog · integrations · releases · adoption actions","Biweekly"],
        ["Content & Experience Council","Product Marketing + Product/LoB + Design CoE + Enablement + Brand","Narrative · templates · components · publication · content health","Biweekly"],
        ["Field Champion Network","Selected users across regions / LoBs / roles","Peer learning · feedback · local reinforcement","Monthly"],
        ["Vendor Operating Review","Platform Owner + Coast","Roadmap · support · defects · security · commercial terms","Monthly / quarterly"]
      ].map(x=>`<div class="card wide"><span class="view-label">${x[3]}</span><h3>${x[0]}</h3><p><b style="color:#e8e9f8">Participants:</b> ${x[1]}</p><p style="margin-top:6px"><b style="color:#e8e9f8">Rights:</b> ${x[2]}</p></div>`).join("")}
    </div>`
  },
  questions: {
    label:"FORMAL DECISION BACKLOG", title:"The questions leadership must answer.", sub:"A deployment is not designed until high-priority questions have explicit answers, owners and review dates.",
    html:`<div class="card full"><input class="search" id="qSearch" placeholder="Search the question bank…"><div class="question-list" id="questionList"></div></div>`
  },
  roadmap: {
    label:"SEQUENCING", title:"30 / 90 / 180 / 365", sub:"A controlled progression from governance to enterprise capability.",
    html:`<div class="grid">${[
      ["0–30 DAYS","Stand up governance; approve charter; define audiences; baseline metrics; select 2–4 use cases; define source of truth; appoint owners; dashboard skeleton.","GOVERN"],
      ["31–90 DAYS","Golden templates; pilot cohort; champions + managers; real customer use; telemetry; support model; productivity baselines; case studies; go/no-go.","PROVE"],
      ["91–180 DAYS","2–4 controlled waves; GTM workflow integration; product/LoB content; automate provisioning/reporting; retirement; manager dashboards.","SCALE"],
      ["181–365 DAYS","Standard enablement/onboarding; external marketing + executive use cases; deeper analytics + CRM linkage; value-led investment reset.","EMBED"]
    ].map(x=>`<div class="card wide"><span class="view-label">${x[2]}</span><h3>${x[0]}</h3><p>${x[1]}</p></div>`).join("")}
    <div class="card full"><span class="view-label">TARGET MATURITY</span><div class="tile-row">${["1 · Experimental","2 · Controlled","3 · Scaled","4 · Integrated","5 · Optimized"].map((x,i)=>`<div class="mini-tile"><strong>${x}</strong><span>${["Proof of concept","Repeatability","Enterprise adoption","Commercial capability","Digital experience operating system"][i]}</span></div>`).join("")}</div><p style="margin-top:14px">Target after 12–18 months: generally Level 3 for priority business units, with selected strategic journeys at Level 4. Level 5 is a strategic horizon.</p></div></div>`
  },
  risk: {
    label:"PROTECT THE INVESTMENT", title:"Risk & maturity", sub:"The scaling failure modes are mostly operating-model failures, not platform failures.",
    html:`<div class="grid"><div class="card full"><div class="risk-grid">${[
      ["Tool becomes another content silo","HIGH / HIGH","Define Coast's role in enterprise content architecture and default routing/publishing patterns."],
      ["Central team becomes bottleneck","HIGH / HIGH","Federate creators; centralize standards and controls, not every build."],
      ["Low seller adoption","HIGH / HIGH","Managers, champions, workflow integration, role-based use cases and behavior metrics."],
      ["Content drift / inaccurate claims","HIGH / HIGH","Named product owners, source-of-truth links, review dates and retirement."],
      ["Poor experience quality","MEDIUM / HIGH","Design CoE, golden templates, QA gate and accessibility standard."],
      ["Security / data leakage","MEDIUM / HIGH","SSO/RBAC, approved data classes, technical review and auditability."],
      ["License proliferation","HIGH / MEDIUM","Cohort-based provisioning and quarterly value review."],
      ["Field creates bespoke experiences","HIGH / MEDIUM","Template-first design, reusable components and reuse metrics."]
    ].map(x=>`<div class="risk"><span class="level ${x[1].startsWith("HIGH")?"high":"medium"}">${x[1]}</span><h4>${x[0]}</h4><p>${x[2]}</p></div>`).join("")}</div></div>
    <div class="card full"><span class="view-label">MATURITY JOURNEY</span><div class="tile-row">${[
      ["1","Experimental"],["2","Controlled"],["3","Scaled"],["4","Integrated"],["5","Optimized"]
    ].map((x,i)=>`<div class="mini-tile" data-maturity="${i}"><strong>${x[0]} · ${x[1]}</strong><span>Open maturity detail</span></div>`).join("")}</div></div></div>`
  },
  decisions: { label:"EXECUTIVE DECISION ROOM", title:"12 decisions before broad rollout.", sub:"These are governance decisions, not implementation details.", html:"" }
};

const questions = {
  "Strategy & value":[
    "What business problem is Coast solving that existing channels do not solve well?",
    "What measurable behaviors should change in sellers, pre-sales, product marketing and customers?",
    "Which revenue motions should Coast improve first?",
    "What is the economic case: hours saved, cycle time, specialist capacity, engagement, conversion, win rate or revenue?",
    "What is the 12-month ambition and what would cause leadership to increase or reduce investment?"
  ],
  "Scope & audience":[
    "Who is eligible to use Coast and who is merely impacted by Coast-produced experiences?",
    "Which roles need creator, editor, reviewer, consumer or analytics access?",
    "Which regions, LoBs and products are first-wave candidates and why?",
    "What is the denominator for adoption reporting?",
    "Which audiences are intentionally out of scope for the first 12 months?"
  ],
  "Buyer journey & use cases":[
    "At which buying stages can interactive self-service meaningfully reduce friction?",
    "Which buyer tasks are most suitable for a digital experience versus human interaction?",
    "Which personas require different stories, evidence or navigation?",
    "What should the buyer be able to understand, decide or do after an experience?",
    "Which use cases are repeatable enough to warrant templates?"
  ],
  "Content truth & governance":[
    "What system is the source of truth for product facts, features, claims and messaging?",
    "Who owns accuracy? Who owns brand? Who owns regulatory review?",
    "How is stale content detected?",
    "What is the maximum acceptable age of an experience without review?",
    "What is the retirement policy?",
    "Which content can be creator-published and which requires approval?"
  ],
  "Experience design":[
    "What are the mandatory UX patterns and what is optional?",
    "What should every Coast experience contain: audience, problem, workflow, proof, next step?",
    "Which templates should be golden paths versus open canvas?",
    "How do we prevent PowerPoint in HTML and instead create true interaction?"
  ],
  "Platform & architecture":[
    "How will SSO, identity and role provisioning work?",
    "Which enterprise systems require integration?",
    "What data is allowed to enter an experience?",
    "How are integrations monitored and supported?",
    "What happens when Coast or a dependency is unavailable?"
  ],
  "Enablement & change":[
    "What behavior changes are expected at individual, manager and team level?",
    "What is the why for each cohort?",
    "What just-in-time learning is needed at the moment of use?",
    "How will managers reinforce the behavior?",
    "How will champions be selected, equipped and recognized?"
  ],
  "Analytics & adoption":[
    "What defines activation, repeat use, depth, quality and embedded adoption?",
    "Can usage be tied to role, region, LoB, product, account and opportunity where privacy policy permits?",
    "Which metrics are leading indicators and which are lagging outcomes?",
    "What is the minimum telemetry required for every shared experience?",
    "How are dormant users and low-adoption teams identified and remediated?"
  ]
};

const decision12 = [
  ["01","What is Coast?","Enterprise platform, demo service, content channel, or strategic digital experience capability?","Defines funding, authority and expectations."],
  ["02","Who is accountable?","Single accountable executive plus named platform/product owner?","Prevents distributed ownership and orphaned decisions."],
  ["03","What behavior is changing?","Which seller / marketer / pre-sales behaviors must become standard?","Makes adoption measurable rather than license-based."],
  ["04","Which audiences are in scope?","Sales, pre-sales, marketing, product, partners, customers, executives?","Defines adoption denominator and roadmap."],
  ["05","What is the source of truth?","Where do product claims, messaging, visuals and data originate?","Controls drift and content risk."],
  ["06","What gets standardized?","Templates, navigation, interaction patterns, story frameworks, naming, publishing?","Controls experience fragmentation."],
  ["07","What stays federated?","LoB / product customization and regional variation?","Balances scale and local relevance."],
  ["08","Who can publish externally?","Who can approve customer-facing content and high-risk experiences?","Creates accountability for brand, product and compliance."],
  ["09","How is value measured?","Adoption, productivity, buyer engagement, pipeline influence, win-rate or cycle-time?","Creates executive ROI discipline."],
  ["10","How will funding work?","Central platform + shared CoE, or chargeback / federated budgets?","Determines scaling behavior."],
  ["11","What is the migration policy?","Does Coast replace, complement or coexist with existing decks/assets?","Avoids platform sprawl and duplicate work."],
  ["12","What is the 12-month ambition?","Pilot, priority LoBs, enterprise standard, or digital experience as default?","Sets investment and sequencing."]
];

function render(view){
  document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.view===view));
  const d=DATA[view] || DATA.mandate;
  const el=document.getElementById("view");
  if(view==="decisions"){
    el.innerHTML=`<div class="view-head"><div><div class="view-label">${d.label}</div><h2>${d.title}</h2><p>${d.sub}</p></div></div>
      <div class="grid">${decision12.map(x=>`<div class="card wide decision" data-decision="${x[0]}"><span class="view-label">${x[0]}</span><h3>${x[1]}</h3><p>${x[2]}</p><p style="margin-top:8px;color:#ddd">${x[3]}</p></div>`).join("")}</div>`;
  }else{
    el.innerHTML=`<div class="view-head"><div><div class="view-label">${d.label}</div><h2>${d.title}</h2><p>${d.sub}</p></div></div>${d.html}`;
  }
  bind();
  if(view==="questions") renderQuestions();
}
function modal(title,body){
  document.getElementById("modalContent").innerHTML=`<h2>${title}</h2>${body}`;
  document.getElementById("modalBackdrop").classList.add("open");
}
function renderQuestions(filter=""){
  const list=document.getElementById("questionList"); if(!list)return;
  const q=Object.entries(questions).flatMap(([cat,arr])=>arr.map(t=>({cat,t}))).filter(x=>x.t.toLowerCase().includes(filter.toLowerCase())||x.cat.toLowerCase().includes(filter.toLowerCase()));
  list.innerHTML=q.map(x=>`<div class="q" data-question="${encodeURIComponent(x.t)}"><span class="pill">${x.cat}</span><div style="margin-top:8px">${x.t}</div></div>`).join("");
}
function bind(){
  document.querySelectorAll("[data-modal]").forEach((e)=>e.onclick=()=>{
    const i=+e.dataset.modal;
    const content=[
      ["Desired behavior","The executive scorecard should focus on adoption of the desired behavior — not license consumption or logins."],
      ["Independent capability","Measure whether sellers and creators can complete core workflows without specialist support."],
      ["Less specialist friction","Track prep time, build time, specialist dependency and time-to-publish to prove operational value."],
      ["Buyer engagement","Measure engagement depth, continuation, sharing and return engagement rather than raw views alone."],
      ["Commercial impact","Track influenced pipeline, stage progression, cycle time and win-rate indicators where sample size allows."]
    ][i]; modal(content[0],`<p>${content[1]}</p><h3>Why it matters</h3><p>The platform itself is the enabler; the operating model must connect this outcome to ownership, telemetry and governance.</p>`);
  });
  document.querySelectorAll("[data-role]").forEach(e=>e.onclick=()=>{
    const roles=[
      ["RevOps","Own enterprise roadmap, operating model, governance, adoption scorecard and value realization."],
      ["Platform Owner","Own backlog, configuration, roles, release management, standards and vendor management."],
      ["Design CoE","Own templates, interaction standards, reusable components, accessibility and UX patterns."],
      ["Product / LoB","Own product truth, use cases, priority workflows, release alignment and content sign-off."],
      ["Enablement","Own training, manager reinforcement, champions, adoption campaigns and behavior measurement."],
      ["Demo Services","Own environment readiness, support, operational SLAs and incident management."],
      ["Marketing","Own internal communications, campaigns, external channel strategy and brand alignment."],
      ["IT / Security","Own SSO, RBAC, data security, integration controls, architecture and risk."],
      ["Data","Own telemetry model, CRM linkage, dashboards, ROI attribution and data quality."],
      ["Sales Leadership","Own local adoption, coaching, inspection and use-case compliance."]
    ][+e.dataset.role]; modal(roles[0],`<p>${roles[1]}</p>`);
  });
  document.querySelectorAll("[data-stage]").forEach(e=>e.onclick=()=>{
    const s=[
      ["0 · Mobilize","Questions: What is the commercial problem? Who is the sponsor? What is in scope? What budget is committed?","Output: charter, outcome tree, stakeholder map, RACI, funding model and risk register."],
      ["1 · Discover","Which journeys, personas and use cases matter? Where do static assets or specialist dependencies slow selling?","Output: journey map, audience segmentation, content inventory, baseline metrics and use-case backlog."],
      ["2 · Design","Who creates, reviews, approves and retires assets? What is the source of truth?","Output: governance charter, RBAC, publishing workflow, templates, taxonomy and support SLAs."],
      ["3 · Build","Can the experience be built once and reused? Is it modular, accurate, accessible and measurable?","Output: reference experiences, components, QA checklist, analytics taxonomy and field playbook."],
      ["4 · Pilot","Do users choose Coast voluntarily? Can managers coach it? Does it remove effort?","Output: telemetry, feedback, time-on-task, prep time, content effectiveness and issue log."],
      ["5 · Scale","What is centralized vs localized? Are champions, managers and support capacity ready?","Output: wave plan, communications, champion kits, dashboards, office hours and heatmap."],
      ["6 · Embed","Is Coast in onboarding, account planning, discovery, demo prep, follow-up or campaigns?","Output: process playbooks, onboarding, manager scorecards, default templates and nudges."],
      ["7 · Optimize","Which experiences engage? Which are stale? Where is specialist support still required?","Output: value review, retirement, A/B tests, backlog and investment decisions."]
    ][+e.dataset.stage]; modal(s[0],`<h3>Key questions</h3><p>${s[1]}</p><h3>Required outputs</h3><p>${s[2]}</p>`);
  });
  document.querySelectorAll("[data-decision]").forEach(e=>e.onclick=()=>{
    const x=decision12.find(d=>d[0]===e.dataset.decision); modal(`${x[0]} · ${x[1]}`,`<p style="font-size:15px;color:#e9eaff">${x[2]}</p><h3>Why it matters</h3><p>${x[3]}</p>`);
  });
  document.querySelectorAll("[data-maturity]").forEach(e=>{
    const x=[
      ["1 · Experimental","A few demos built; no formal ownership; success measured by novelty.","Proof of concept"],
      ["2 · Controlled","Templates, access, support and governance exist; priority use cases defined.","Repeatability"],
      ["3 · Scaled","Federated creation, champions, telemetry and manager adoption are operating.","Enterprise adoption"],
      ["4 · Integrated","Coast is embedded in GTM workflows and content architecture; buyer engagement informs action.","Commercial capability"],
      ["5 · Optimized","Experiences are dynamically orchestrated, continuously measured, AI-assisted and managed as a portfolio.","Digital experience operating system"]
    ][+e.dataset.maturity]; modal(x[0],`<p>${x[1]}</p><h3>Management outcome</h3><p>${x[2]}</p>`);
  });
  const search=document.getElementById("qSearch"); if(search)search.oninput=()=>renderQuestions(search.value);
  document.querySelectorAll("[data-question]").forEach(e=>e.onclick=()=>modal("Decision question",`<p style="font-size:15px;color:#e9eaff">${decodeURIComponent(e.dataset.question)}</p><h3>Governance prompt</h3><p>Assign an explicit owner, answer, evidence source and review date before the question is considered closed.</p>`));
}
document.addEventListener("click",e=>{
  const b=e.target.closest("[data-view]"); if(b){render(b.dataset.view);window.scrollTo({top:0,behavior:"smooth"})}
});
document.getElementById("modalClose").onclick=()=>document.getElementById("modalBackdrop").classList.remove("open");
document.getElementById("modalBackdrop").onclick=e=>{if(e.target.id==="modalBackdrop")e.currentTarget.classList.remove("open")};
document.addEventListener("keydown",e=>{if(e.key==="Escape")document.getElementById("modalBackdrop").classList.remove("open")});
document.getElementById("themeBtn").onclick=()=>document.body.classList.toggle("light");
render("mandate");
