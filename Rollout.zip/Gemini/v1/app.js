// --- Data model derived from your documents ---

const pillars = [
  {
    id: "pillar1",
    label: "Pillar 1",
    title: "Strategy, Value Realization & Executive Alignment",
    summary:
      "Clarify commercial intent, investment model, and executive success criteria for Coast deployment.",
    execQuestions: [
      "What is the precise distribution of Coast use cases across the buyer journey (async tours, live demos, leave-behinds, onboarding)?",
      "Should Coast replace legacy sandbox environments entirely for Tier-1/Tier-2 demos, or run in a hybrid model?",
      "Who is the single executive point of accountability responsible for cross-functional alignment and resolving impasses?",
      "What explicit payback period (e.g., 6, 12, 18 months) is expected by executive leadership?"
    ],
    opsQuestions: [
      "How will platform licensing be funded (central RevOps/IT vs. LOB chargeback based on seat usage or tour volume)?",
      "How will incremental seat expansions, premium integrations, and vendor services be approved as adoption grows?",
      "What baseline cost of maintaining legacy demo sandboxes and SE maintenance hours can be offset against Coast’s TCO?",
      "How will Steering Committee cadence and mandate be defined to maintain alignment across Product, Marketing, and Sales?"
    ]
  },
  {
    id: "pillar2",
    label: "Pillar 2",
    title: "Content Architecture & GTM Storytelling",
    summary:
      "Govern brand design systems, product prioritization, capture mechanics, and narrative branching.",
    execQuestions: [
      "Which product lines represent Tier-1 priorities for standardized demo templates and what criteria define Tier-2/Tier-3 onboarding?",
      "How will multi-product solution stories be stitched together into coherent Coast tours?",
      "Who holds final sign-off authority to ensure captured UI flows reflect latest brand guidelines?",
      "What is the structural taxonomy for demo flows (executive overview, standard presentation, deep-dive technical tour)?"
    ],
    opsQuestions: [
      "How will corporate Marketing govern themes, typography, and color palettes within Coast to maintain brand compliance?",
      "What balance will be struck between interactive DOM-based cloning, static screens, and embedded video elements?",
      "What triggers template updates when product teams release major UI overhauls or micro-updates?",
      "How will localized content (languages, currencies, regulatory disclaimers) be managed across EMEA, AMER, and APAC?"
    ]
  },
  {
    id: "pillar3",
    label: "Pillar 3",
    title: "Technical Integration, Security & Data Governance",
    summary:
      "Define PII masking, identity and access, CRM/MAP integration, and external buyer security.",
    execQuestions: [
      "How will real PII, customer accounts, and sensitive transactional data be detected and synthetically replaced during capture?",
      "What regulatory frameworks (GDPR, SOC 2, PCI-DSS, etc.) must Coast comply with in this FinTech context?",
      "What RBAC tiers are required (Global Admin, LOB Author, SE Customizer, AE Presenter, External Viewer)?",
      "How will engagement analytics influence deal health scores and rep alerts in Salesforce/HubSpot?"
    ],
    opsQuestions: [
      "How will SSO (SAML/OIDC) and SCIM provisioning automate onboarding/offboarding across 70,000 employees?",
      "How will Coast telemetry be exported into corporate data warehouses for BI dashboards?",
      "What security controls (domain-locking, password protection, link expiration) will be enforced on leave-behind links?",
      "What SLA and failover plan exist for live customer-facing presentations if Coast experiences an outage?"
    ]
  },
  {
    id: "pillar4",
    label: "Pillar 4",
    title: "Operational Support & Platform Ownership",
    summary:
      "Establish CoE operating model, SLAs, field customization boundaries, and licensing operations.",
    execQuestions: [
      "Will content creation follow a centralized, decentralized, or hybrid federated model?",
      "What dedicated headcount and roles are required within the Demo Center of Excellence?",
      "What SLAs govern new master template creation and updates following product releases?",
      "How will seat licenses be allocated, monitored, and reclaimed from inactive users?"
    ],
    opsQuestions: [
      "What multi-stage approval workflow must templates pass before publication (Author → Product → Marketing → Infosec)?",
      "How will unauthorized or misleading changes to product capabilities be prevented in field customizations?",
      "How will user-generated variations be tracked to identify high-performing rep modifications?",
      "How will template libraries be organized (taxonomy, tagging, versioning) to allow reps to locate tours in under 30 seconds?"
    ]
  },
  {
    id: "pillar5",
    label: "Pillar 5",
    title: "Enablement & Behavioral Change Management",
    summary:
      "Design role-based curricula, manage cultural transition, and embed feedback loops.",
    execQuestions: [
      "What distinct training paths will be created for Authors, Presenters, Customizers, and RevOps/Managers?",
      "Will platform certification be mandatory before reps can create and send Coast links?",
      "How will leadership address resistance from veteran reps attached to legacy sandbox demos or slide decks?",
      "What gamification or recognition programs will accelerate early adoption (e.g., Demo of the Month)?"
    ],
    opsQuestions: [
      "How will enablement materials be embedded into existing learning platforms (Highspot, Seismic, Docebo, etc.)?",
      "How will managers incorporate Coast usage and buyer engagement metrics into weekly deal reviews?",
      "How will call-recording platforms (Gong, Chorus) be integrated to analyze pitch effectiveness?",
      "What mechanisms will reps use to submit bug reports and template improvement ideas directly to Demo Services?"
    ]
  }
];

const raciActivities = [
  {
    title: "Platform Vision, Funding & Business Case",
    description: "Define enterprise DEMP vision, funding model, and 12-month business case metrics.",
    roles: [
      { function: "Executive Sponsor", role: "A" },
      { function: "RevOps / Tech Services", role: "R" },
      { function: "Demo Services Group", role: "C" },
      { function: "Product GTM / LOB", role: "C" },
      { function: "Corp Marketing", role: "I" },
      { function: "Sales Enablement", role: "I" },
      { function: "Pre-Sales (SEs)", role: "I" },
      { function: "Direct Sales (AEs)", role: "I" },
      { function: "Enterprise IT / Sec", role: "I" }
    ]
  },
  {
    title: "Infosec, Compliance & SSO Procurement",
    description: "Secure Coast platform, identity, and compliance posture.",
    roles: [
      { function: "Executive Sponsor", role: "I" },
      { function: "RevOps / Tech Services", role: "C" },
      { function: "Demo Services Group", role: "C" },
      { function: "Product GTM / LOB", role: "I" },
      { function: "Corp Marketing", role: "I" },
      { function: "Sales Enablement", role: "I" },
      { function: "Pre-Sales (SEs)", role: "I" },
      { function: "Direct Sales (AEs)", role: "I" },
      { function: "Enterprise IT / Sec", role: "A/R" }
    ]
  },
  {
    title: "Brand Design Systems & Canvas Guidelines",
    description: "Maintain brand compliance across all Coast canvases and demo templates.",
    roles: [
      { function: "Executive Sponsor", role: "I" },
      { function: "RevOps / Tech Services", role: "I" },
      { function: "Demo Services Group", role: "C" },
      { function: "Product GTM / LOB", role: "C" },
      { function: "Corp Marketing", role: "A/R" },
      { function: "Sales Enablement", role: "I" },
      { function: "Pre-Sales (SEs)", role: "I" },
      { function: "Direct Sales (AEs)", role: "I" },
      { function: "Enterprise IT / Sec", role: "I" }
    ]
  },
  {
    title: "Product UI Capture & Baseline Authoring",
    description: "Capture product UI and author baseline demo templates.",
    roles: [
      { function: "Executive Sponsor", role: "I" },
      { function: "RevOps / Tech Services", role: "C" },
      { function: "Demo Services Group", role: "A/R" },
      { function: "Product GTM / LOB", role: "C" },
      { function: "Corp Marketing", role: "I" },
      { function: "Sales Enablement", role: "I" },
      { function: "Pre-Sales (SEs)", role: "C" },
      { function: "Direct Sales (AEs)", role: "I" },
      { function: "Enterprise IT / Sec", role: "I" }
    ]
  },
  {
    title: "Usage Analytics & Executive Business Reviews",
    description: "Analyze Coast usage and present ROI metrics to leadership.",
    roles: [
      { function: "Executive Sponsor", role: "C" },
      { function: "RevOps / Tech Services", role: "A/R" },
      { function: "Demo Services Group", role: "R" },
      { function: "Product GTM / LOB", role: "C" },
      { function: "Corp Marketing", role: "I" },
      { function: "Sales Enablement", role: "C" },
      { function: "Pre-Sales (SEs)", role: "I" },
      { function: "Direct Sales (AEs)", role: "I" },
      { function: "Enterprise IT / Sec", role: "I" }
    ]
  }
];

const phases = [
  {
    id: "phase1",
    label: "Phase 1",
    title: "Foundation & Governance",
    range: "Weeks 1–4",
    bullets: ["Architecture & InfoSec sign-off", "SSO/SCIM integration", "Establish Demo CoE"],
    milestones: [
      "Finalize enterprise architecture, SSO SAML 2.0 integration, and InfoSec data-masking protocols.",
      "Establish the Demo Center of Excellence (CoE) comprising RevOps, Demo Services Group, and Product GTM leads.",
      "Define taxonomy for product suites, vertical industries, and buyer journey stages within Coast."
    ]
  },
  {
    id: "phase2",
    label: "Phase 2",
    title: "Core Asset & Template Architecture",
    range: "Weeks 5–8",
    bullets: ["Marketing design system integration", "Top LOB product captures", "Synthetic demo data"],
    milestones: [
      "Author standardized global templates for the top 20% of product lines driving 80% of revenue.",
      "Establish synthetic data sets compliant with banking regulations (GDPR, SOC2, HIPAA where applicable).",
      "Build CRM triggers to auto-generate personalized Coast links directly within opportunity records."
    ]
  },
  {
    id: "phase3",
    label: "Phase 3",
    title: "Pilot Launch & Lighthouse Validation",
    range: "Weeks 9–12",
    bullets: ["Onboard 50–100 AEs/SEs", "Test async vs live modes", "Refine templates via telemetry"],
    milestones: [
      "Deploy pilot program across a select cohort spanning Pre-Sales and Direct Sales in a primary LOB.",
      "Gather qualitative rep feedback and quantitative buyer engagement data (completion rates, re-shares).",
      "Tune narrative flows, step descriptions, and interactive callouts based on drop-off analytics."
    ]
  },
  {
    id: "phase4",
    label: "Phase 4",
    title: "Global Enterprise Rollout",
    range: "Weeks 13–20",
    bullets: ["Tiered certification", "CRM automation", "Weekly regional office hours"],
    milestones: [
      "Initiate global enablement across all operating divisions and lines of business.",
      "Enforce mandatory platform certification for rep link creation privileges.",
      "Transition legacy sandbox access to Coast for standard tier-1 and tier-2 prospect interactions."
    ]
  },
  {
    id: "phase5",
    label: "Phase 5",
    title: "Steady-State Scale & Optimization",
    range: "Continuous",
    bullets: ["Automated product release updates", "Win/loss attribution modeling", "Template deprecation lifecycle"],
    milestones: [
      "Establish bi-weekly release syncs between Product Management and Demo Services Group for UI updates.",
      "Perform quarterly audit of published templates; retire low-performing or outdated flows.",
      "Report platform ROI and attribution metrics to executive leadership."
    ]
  }
];

const adoptionData = {
  labels: ["Day 30", "Day 60", "Day 90", "Day 180"],
  se: [60, 85, 95, 98],
  ae: [20, 40, 65, 80]
};

const resistancePoints = [
  {
    title: "Loss of Control",
    description:
      "Reps fear canned narratives will not address edge cases or bespoke buyer scenarios.",
    mitigation:
      "Build modular branch points within templates so presenters can dynamically pivot based on prospect responses."
  },
  {
    title: "Lack of Staging",
    description:
      "Reps want bespoke staging environments tailored to each opportunity.",
    mitigation:
      "Allow variable text fields, custom callouts, and light-weight personalization without breaking master templates."
  },
  {
    title: "Over-Complexity",
    description:
      "Reps perceive the tool as unintuitive or slow to navigate during live calls.",
    mitigation:
      "Implement 1-click link generation inside Salesforce/HubSpot and streamline presenter workflows."
  },
  {
    title: "Legacy Attachment",
    description:
      "Veteran reps remain attached to traditional sandbox demos and slide decks.",
    mitigation:
      "Introduce sunsetting schedules, clear policies, and gamified recognition for Coast-first demo behavior."
  }
];

const tier1Metrics = [
  "Platform Adoption Rate (Active Users / Provisioned Licenses)",
  "Buyer Engagement Depth (average tour completion percentage)",
  "Multi-Threading Index (unique stakeholders per opportunity link)",
  "Template Utilization Velocity (experiences generated by product line and stage)"
];

const tier2Metrics = [
  "Sales Velocity Impact (cycle length delta for Coast vs legacy demos)",
  "SE Efficiency Gain (hours saved per SE per week on staging and resets)",
  "Win Rate Uplift (conversion delta for deals with interactive leave-behinds)",
  "Opportunity Acceleration Rate (speed from Discovery to Demo Complete)"
];

// --- DOM helpers ---

const qs = (sel) => document.querySelector(sel);
const qsa = (sel) => Array.from(document.querySelectorAll(sel));

function createEl(tag, className, text) {
  const el = document.createElement(tag);
  if (className) el.className = className;
  if (text) el.textContent = text;
  return el;
}

// --- Navigation between sections ---

function initNavigation() {
  const navItems = qsa(".nav-item");
  navItems.forEach((item) => {
    item.addEventListener("click", () => {
      const target = item.dataset.section;
      navItems.forEach((n) => n.classList.remove("active"));
      item.classList.add("active");

      qsa(".section").forEach((section) => {
        section.classList.toggle(
          "active",
          section.id === `section-${target}`
        );
      });
    });
  });
}

// --- Pillars grid & modal ---

function renderPillars() {
  const grid = qs(".pillars-grid");
  pillars.forEach((pillar) => {
    const card = createEl("div", "pillar-card");
    card.dataset.pillarId = pillar.id;

    const label = createEl("div", "pillar-label", pillar.label);
    const title = createEl("div", "pillar-title", pillar.title);
    const summary = createEl("div", "pillar-summary", pillar.summary);

    const meta = createEl("div", "pillar-meta");
    const badge = createEl("span", "badge", "Exec + Ops");
    const count = createEl(
      "span",
      "",
      `${pillar.execQuestions.length + pillar.opsQuestions.length} key questions`
    );
    meta.appendChild(badge);
    meta.appendChild(count);

    card.appendChild(label);
    card.appendChild(title);
    card.appendChild(summary);
    card.appendChild(meta);

    card.addEventListener("click", () => openPillarModal(pillar));

    grid.appendChild(card);
  });
}

function openPillarModal(pillar) {
  const overlay = qs("#pillarModal");
  qs("#pillarModalTitle").textContent = pillar.title;
  qs("#pillarModalIntro").textContent = pillar.summary;

  const execContainer = qs("#execQuestions");
  const opsContainer = qs("#opsQuestions");
  execContainer.innerHTML = "";
  opsContainer.innerHTML = "";

  const execList = createEl("ul");
  pillar.execQuestions.forEach((q) => {
    const li = createEl("li");
    li.textContent = `• ${q}`;
    execList.appendChild(li);
  });
  execContainer.appendChild(execList);

  const opsList = createEl("ul");
  pillar.opsQuestions.forEach((q) => {
    const li = createEl("li");
    li.textContent = `• ${q}`;
    opsList.appendChild(li);
  });
  opsContainer.appendChild(opsList);

  // reset tabs
  qsa(".modal-tab").forEach((tab) => tab.classList.remove("active"));
  qsa(".modal-tab-content").forEach((content) =>
    content.classList.remove("active")
  );
  qs(".modal-tab[data-tab='execQuestions']").classList.add("active");
  execContainer.classList.add("active");

  overlay.classList.add("active");
}

// --- RACI grid & modal ---

function renderRaci() {
  const grid = qs(".raci-grid");
  raciActivities.forEach((activity) => {
    const card = createEl("div", "raci-card");
    card.dataset.raciTitle = activity.title;

    const title = createEl("div", "raci-card-title", activity.title);
    const subtitle = createEl("div", "raci-card-subtitle", activity.description);

    const rolesWrap = createEl("div", "raci-card-roles");
    activity.roles.slice(0, 4).forEach((r) => {
      const chip = createEl(
        "span",
        "badge",
        `${r.function.split(" ")[0]}: ${r.role}`
      );
      rolesWrap.appendChild(chip);
    });

    card.appendChild(title);
    card.appendChild(subtitle);
    card.appendChild(rolesWrap);

    card.addEventListener("click", () => openRaciModal(activity));

    grid.appendChild(card);
  });
}

function openRaciModal(activity) {
  const overlay = qs("#raciModal");
  qs("#raciModalTitle").textContent = activity.title;
  qs("#raciModalDesc").textContent = activity.description;

  const tbody = qs("#raciModalBody");
  tbody.innerHTML = "";
  activity.roles.forEach((r) => {
    const tr = document.createElement("tr");
    const tdFunc = document.createElement("td");
    const tdRole = document.createElement("td");
    tdFunc.textContent = r.function;
    tdRole.textContent = r.role;
    tr.appendChild(tdFunc);
    tr.appendChild(tdRole);
    tbody.appendChild(tr);
  });

  overlay.classList.add("active");
}

// --- Timeline & phase modal ---

function renderTimeline() {
  const container = qs(".timeline");
  phases.forEach((phase) => {
    const step = createEl("div", "timeline-step");
    step.dataset.phaseId = phase.id;

    const label = createEl("div", "timeline-label", phase.label);
    const title = createEl("div", "timeline-title", phase.title);
    const range = createEl("div", "timeline-range", phase.range);

    const bullets = createEl("div", "timeline-bullets");
    bullets.textContent = phase.bullets.join(" • ");

    step.appendChild(label);
    step.appendChild(title);
    step.appendChild(range);
    step.appendChild(bullets);

    step.addEventListener("click", () => openPhaseModal(phase));

    container.appendChild(step);
  });
}

function openPhaseModal(phase) {
  const overlay = qs("#phaseModal");
  qs("#phaseModalTitle").textContent = phase.title;
  qs("#phaseModalRange").textContent = phase.range;

  const list = qs("#phaseModalMilestones");
  list.innerHTML = "";
  phase.milestones.forEach((m) => {
    const li = document.createElement("li");
    li.textContent = m;
    list.appendChild(li);
  });

  overlay.classList.add("active");
}

// --- Adoption chart (simple custom canvas rendering) ---

function renderAdoptionChart() {
  const canvas = qs("#adoptionChart");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const { labels, se, ae } = adoptionData;

  const width = canvas.width;
  const height = canvas.height;
  ctx.clearRect(0, 0, width, height);

  const padding = 32;
  const chartWidth = width - padding * 2;
  const chartHeight = height - padding * 2;

  const maxValue = 100;
  const stepX = chartWidth / (labels.length - 1);

  function yFor(value) {
    const ratio = value / maxValue;
    return height - padding - ratio * chartHeight;
  }

  // Background grid
  ctx.strokeStyle = "rgba(148,163,184,0.25)";
  ctx.lineWidth = 1;
  [0, 25, 50, 75, 100].forEach((v) => {
    const y = yFor(v);
    ctx.beginPath();
    ctx.moveTo(padding, y);
    ctx.lineTo(width - padding, y);
    ctx.stroke();
  });

  // Axes labels
  ctx.fillStyle = "#9ca3af";
  ctx.font = "12px system-ui";
  labels.forEach((label, i) => {
    const x = padding + i * stepX;
    const y = height - padding + 16;
    ctx.fillText(label, x - 20, y);
  });

  // SE line
  ctx.strokeStyle = "#22c55e";
  ctx.lineWidth = 2;
  ctx.beginPath();
  se.forEach((v, i) => {
    const x = padding + i * stepX;
    const y = yFor(v);
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.stroke();

  // AE line
  ctx.strokeStyle = "#8b5cf6";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ae.forEach((v, i) => {
    const x = padding + i * stepX;
    const y = yFor(v);
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.stroke();

  // Legend
  ctx.fillStyle = "#e5e7eb";
  ctx.font = "11px system-ui";
  ctx.fillText("SE WAU", padding + 8, padding + 8);
  ctx.fillText("AE WAU", padding + 80, padding + 8);
}

// --- Resistance tiles & modal ---

function renderResistance() {
  const grid = qs(".resistance-grid");
  resistancePoints.forEach((point) => {
    const card = createEl("div", "resistance-card");
    card.dataset.resistanceTitle = point.title;

    const title = createEl("div", "resistance-title", point.title);
    const desc = createEl("div", "resistance-desc", point.description);

    card.appendChild(title);
    card.appendChild(desc);

    card.addEventListener("click", () => openResistanceModal(point));

    grid.appendChild(card);
  });
}

function openResistanceModal(point) {
  const overlay = qs("#resistanceModal");
  qs("#resistanceModalTitle").textContent = point.title;
  qs("#resistanceModalDesc").textContent = point.description;
  qs("#resistanceModalMitigation").textContent = point.mitigation;
  overlay.classList.add("active");
}

// --- Measurement metrics ---

function renderMetrics() {
  const tier1List = qs("#tier1List");
  const tier2List = qs("#tier2List");
  tier1List.innerHTML = "";
  tier2List.innerHTML = "";

  tier1Metrics.forEach((m) => {
    const li = document.createElement("li");
    li.textContent = `• ${m}`;
    tier1List.appendChild(li);
  });

  tier2Metrics.forEach((m) => {
    const li = document.createElement("li");
    li.textContent = `• ${m}`;
    tier2List.appendChild(li);
  });
}

// --- Modals generic handling ---

function initModals() {
  // Close buttons
  qsa(".modal-close").forEach((btn) => {
    btn.addEventListener("click", () => {
      const target = btn.dataset.close;
      if (target) {
        qs(`#${target}`).classList.remove("active");
      } else {
        btn.closest(".modal-overlay").classList.remove("active");
      }
    });
  });

  // Overlay click to close
  qsa(".modal-overlay").forEach((overlay) => {
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) {
        overlay.classList.remove("active");
      }
    });
  });

  // Header modals
  qs("#openOverviewModal").addEventListener("click", () => {
    qs("#overviewModal").classList.add("active");
  });
  qs("#openKpiModal").addEventListener("click", () => {
    qs("#kpiModal").classList.add("active");
  });

  // Pillar modal tabs
  qsa(".modal-tab").forEach((tab) => {
    tab.addEventListener("click", () => {
      const target = tab.dataset.tab;
      qsa(".modal-tab").forEach((t) => t.classList.remove("active"));
      tab.classList.add("active");

      qsa(".modal-tab-content").forEach((content) => {
        content.classList.toggle("active", content.id === target);
      });
    });
  });
}

// --- Mode toggle (Exec vs Ops) ---

function initModeToggle() {
  const buttons = qsa(".toggle-btn");
  buttons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const mode = btn.dataset.mode;
      buttons.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");

      // Simple visual hint: in Ops mode, emphasize detailed cards via border
      const contentPanel = qs(".content-panel");
      if (mode === "ops") {
        contentPanel.style.borderColor = "rgba(139,92,246,0.8)";
      } else {
        contentPanel.style.borderColor = "rgba(31,41,55,0.8)";
      }
    });
  });
}

// --- Init ---

window.addEventListener("load", () => {
  initNavigation();
  renderPillars();
  renderRaci();
  renderTimeline();
  renderAdoptionChart();
  renderResistance();
  renderMetrics();
  initModals();
  initModeToggle();
});